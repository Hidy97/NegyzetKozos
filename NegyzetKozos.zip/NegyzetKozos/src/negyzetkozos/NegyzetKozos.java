package negyzetkozos;

public class NegyzetKozos {

    public static void main(String[] args) {
        //Családi Alexandra
        //Dreilinger Maja
        //NegyzetKozos.feladat();
        new NegyzetKozos().feladat();
    }

    private static void feladat() {
        Negyzet negyzet1 = new Negyzet(4, new Koordinata(7, 3));
        Negyzet negyzet2 = new Negyzet(8, new Koordinata(2, 5));
        Negyzet negyzet3 = new Negyzet(6, new Koordinata(9, 1));
        
        System.out.println("Egyformák? " + negyzet1.equals(negyzet2));
        System.out.println("Egyformák? " + negyzet1.equals(negyzet3));
        
        System.out.println("negyzet1hashCode" + negyzet1.hashCode());
        System.out.println("negyzet2hashCode" + negyzet2.hashCode());
        System.out.println("negyzet3hashCode" + negyzet3.hashCode());
        
        
    }
}
